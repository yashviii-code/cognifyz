    const btn = document.getElementById('colorBtn');
    btn.addEventListener('click', () => {
      const colors = ['#e91e63', '#03a9f4', '#4caf50', '#ff9800', '#9c27b0'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      btn.style.backgroundColor = randomColor;
    });

    // Greeting Message
    function showGreeting() {
      const hour = new Date().getHours();
      let greeting;

      if (hour < 12) {
        greeting = "Good Morning!";
      } else if (hour < 18) {
        greeting = "Good Afternoon!";
      } else {
        greeting = "Good Evening!";
      }

      alert(`${greeting} Hope you're having a great day!`);
    }

    // Calculator
    function calculateSum(event) {
      event.preventDefault();
      const num1 = parseFloat(document.getElementById('num1').value);
      const num2 = parseFloat(document.getElementById('num2').value);
      const sum = num1 + num2;

      document.getElementById('calcResult').textContent = `Result: ${sum}`;
    }

    // Background Theme Changer
    function changeBackgroundColor() {
      const bgColors = ['#1abc9c', '#f39c12', '#8e44ad', '#3498db', '#2ecc71', '#d35400', '#34495e'];
      const randomBg = bgColors[Math.floor(Math.random() * bgColors.length)];
      document.body.style.backgroundColor = randomBg;
    }
