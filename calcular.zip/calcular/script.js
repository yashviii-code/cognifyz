const display = document.getElementById('display');
const buttons = document.querySelectorAll('button');
let currentInput = '';

const operators = {
  '+': '+',
  '−': '-',
  '×': '*',
  '÷': '/',
};

function updateDisplay(value) {
  display.textContent = value;
}

function calculate() {
  try {
    const result = eval(currentInput);
    updateDisplay(result);
    currentInput = result.toString();
  } catch (error) {
    updateDisplay('Error');
    currentInput = '';
  }
}

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.textContent;

    if (value === 'C') {
      currentInput = '';
      updateDisplay('0');
    } else if (value === '=') {
      calculate();
    } else if (value in operators) {
      currentInput += operators[value];
      updateDisplay(currentInput);
    } else {
      currentInput += value;
      updateDisplay(currentInput);
    }
  });
});

document.addEventListener('keydown', (e) => {
  const key = e.key;
  if (!isNaN(key) || key === '.') {
    currentInput += key;
    updateDisplay(currentInput);
  } else if (key === 'Enter') {
    calculate();
  } else if (key === 'Escape') {
    currentInput = '';
    updateDisplay('0');
  } else if (['+', '-', '*', '/'].includes(key)) {
    currentInput += key;
    updateDisplay(currentInput);
  }
});