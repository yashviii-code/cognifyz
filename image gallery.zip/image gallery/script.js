document.addEventListener('DOMContentLoaded', () => {
    const galleryItems = document.querySelectorAll('.gallery-item');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const lightbox = document.querySelector('.lightbox');
    const lightboxImg = document.querySelector('.lightbox-img');
    const lightboxCaption = document.querySelector('.lightbox-caption');
    const closeBtn = document.querySelector('.close-btn');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const currentYearSpan = document.getElementById('current-year');

    let currentIndex = 0; // To keep track of the current image in the lightbox
    let filteredItems = []; // To store currently visible images for navigation

    // Set current year in footer
    currentYearSpan.textContent = new Date().getFullYear();

    // --- Image Filtering ---
    filterButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const filter = e.target.dataset.filter;

            // Remove 'active' class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add 'active' class to the clicked button
            e.target.classList.add('active');

            filterImages(filter);
        });
    });

    function filterImages(filter) {
        filteredItems = []; // Reset filtered items
        galleryItems.forEach(item => {
            const category = item.dataset.category;
            if (filter === 'all' || category === filter) {
                item.style.display = 'block'; // Show the item
                filteredItems.push(item); // Add to filtered list
            } else {
                item.style.display = 'none'; // Hide the item
            }
        });
    }

    // Initialize with 'all' images visible
    filterImages('all');

    // --- Lightbox Functionality ---

    galleryItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            // Find the index of this item within the currently filtered items
            currentIndex = filteredItems.indexOf(item);
            openLightbox(filteredItems[currentIndex]);
        });
    });

    function openLightbox(item) {
        const imgSrc = item.querySelector('img').src;
        const imgAlt = item.querySelector('img').alt;
        const overlayTitle = item.querySelector('.overlay h3').textContent;
        const overlayDesc = item.querySelector('.overlay p').textContent;

        lightboxImg.src = imgSrc;
        lightboxImg.alt = imgAlt;
        lightboxCaption.innerHTML = `<h3>${overlayTitle}</h3><p>${overlayDesc}</p>`; // Use innerHTML for dynamic content
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent scrolling while lightbox is open
    }

    function closeLightbox() {
        lightbox.classList.remove('active');
        document.body.style.overflow = 'auto'; // Re-enable scrolling
    }

    closeBtn.addEventListener('click', closeLightbox);

    // Close lightbox when clicking outside the image
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });

    // Keyboard navigation (Escape to close, arrows for next/prev)
    document.addEventListener('keydown', (e) => {
        if (lightbox.classList.contains('active')) {
            if (e.key === 'Escape') {
                closeLightbox();
            } else if (e.key === 'ArrowLeft') {
                navigateLightbox(-1);
            } else if (e.key === 'ArrowRight') {
                navigateLightbox(1);
            }
        }
    });

    // Next/Prev Lightbox Navigation
    prevBtn.addEventListener('click', () => navigateLightbox(-1));
    nextBtn.addEventListener('click', () => navigateLightbox(1));

    function navigateLightbox(direction) {
        currentIndex += direction;

        if (currentIndex < 0) {
            currentIndex = filteredItems.length - 1; // Loop to last image
        } else if (currentIndex >= filteredItems.length) {
            currentIndex = 0; // Loop to first image
        }

        openLightbox(filteredItems[currentIndex]);
    }
});